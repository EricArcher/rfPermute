# rfPermute 1.9.3

## Additions

## Bug Fixes

* Fixed import declarations to avoid grid name clashes
* Fixed logic error in clean.rf.data where fixed predictors were not removed
* Fixed error in use of main argument in plot.rp.importance


# rfPermute 1.9.2

## Additions

* Added this NEWS.md
* Added README.md
* Added num.cores argument to rfPermute to take advantage of multi-threading 

## Changes

* Added internal keyword to calc.imp.pval to keep it from indexing
* Updated imports to match new CRAN policies

## Bug Fixes
