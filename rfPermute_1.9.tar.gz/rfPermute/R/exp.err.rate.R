#' @title Expected Error Rate
#' @description Calculate expected OOB error rates based on random assignment 
#'   and class sizes (prior).
#' 
#' @param rp an \code{\link{rfPermute}} object with a \code{null.dist} element.
#' 
#' @return a vector of expected error rates.
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}
#' 
#' @export
exp.err.rate <- function(rp) {
  y.freq <- table(rp$y)
  exp.err <- 1 - y.freq / sum(y.freq)
  oob.err <- sum(exp.err * y.freq) / sum(y.freq)
  c(OOB = oob.err, exp.err)
}
