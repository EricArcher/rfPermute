# rfPermute 1.9.2

## Additions

* Added this NEWS.md
* Added README.md
* Added num.cores argument to rfPermute to take advantage of multi-threading 
## Changes

* Added internal keyword to calc.imp.pval to keep it from indexing
* Updated imports to match new CRAN policies

## Bug Fixes
